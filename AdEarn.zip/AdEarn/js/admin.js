// Admin panel functionality for AdEarn platform
class AdminPanel {
    constructor() {
        this.currentSection = 'dashboard';
        this.initializeAdmin();
    }
    
    // Initialize admin panel
    initializeAdmin() {
        // Check admin authentication
        if (!this.isAdminAuthenticated()) {
            window.location.href = 'admin-login.html';
            return;
        }
        
        this.setupEventListeners();
        this.loadDashboardData();
        this.initializeModals();
    }
    
    // Check if admin is authenticated
    isAdminAuthenticated() {
        const sessionData = JSON.parse(localStorage.getItem('adminSession') || sessionStorage.getItem('adminSession') || 'null');
        
        if (!sessionData) return false;
        
        const currentTime = Date.now();
        const sessionAge = currentTime - sessionData.loginTime;
        const maxAge = sessionData.rememberMe ? 24 * 60 * 60 * 1000 : 4 * 60 * 60 * 1000;
        
        return sessionAge < maxAge;
    }
    
    // Setup event listeners
    setupEventListeners() {
        // Navigation menu
        document.querySelectorAll('.menu-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const section = item.dataset.section;
                this.switchSection(section);
            });
        });
        
        // Logout button
        document.getElementById('adminLogout').addEventListener('click', () => {
            this.logout();
        });
        
        // Search functionality
        this.setupSearchListeners();
        
        // Form submissions
        this.setupFormListeners();
        
        // Filter functionality
        this.setupFilterListeners();
    }
    
    // Setup search listeners
    setupSearchListeners() {
        const userSearch = document.getElementById('userSearch');
        if (userSearch) {
            userSearch.addEventListener('input', (e) => {
                this.filterUsers(e.target.value);
            });
        }
        
        const adSearch = document.getElementById('adSearch');
        if (adSearch) {
            adSearch.addEventListener('input', (e) => {
                this.filterAds(e.target.value);
            });
        }
    }
    
    // Setup form listeners
    setupFormListeners() {
        // Payment settings form
        const paymentForm = document.getElementById('paymentSettings');
        if (paymentForm) {
            paymentForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.savePaymentSettings();
            });
        }
        
        // Ad settings form
        const adForm = document.getElementById('adSettings');
        if (adForm) {
            adForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveAdSettings();
            });
        }
        
        // User form
        const userForm = document.getElementById('userForm');
        if (userForm) {
            userForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveUser();
            });
        }
        
        // Ad form
        const adFormModal = document.getElementById('adForm');
        if (adFormModal) {
            adFormModal.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveAd();
            });
        }
    }
    
    // Setup filter listeners
    setupFilterListeners() {
        const filterEarnings = document.getElementById('filterEarnings');
        if (filterEarnings) {
            filterEarnings.addEventListener('click', () => {
                this.filterEarningsHistory();
            });
        }
        
        // Platform actions
        const clearCache = document.getElementById('clearCache');
        if (clearCache) {
            clearCache.addEventListener('click', () => {
                this.clearCache();
            });
        }
        
        const backupData = document.getElementById('backupData');
        if (backupData) {
            backupData.addEventListener('click', () => {
                this.backupData();
            });
        }
        
        const resetPlatform = document.getElementById('resetPlatform');
        if (resetPlatform) {
            resetPlatform.addEventListener('click', () => {
                this.resetPlatform();
            });
        }
    }
    
    // Switch between admin sections
    switchSection(sectionName) {
        // Update active menu item
        document.querySelectorAll('.menu-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');
        
        // Show section
        document.querySelectorAll('.admin-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(sectionName).classList.add('active');
        
        this.currentSection = sectionName;
        this.loadSectionData(sectionName);
    }
    
    // Load section-specific data
    loadSectionData(section) {
        switch(section) {
            case 'dashboard':
                this.loadDashboardData();
                break;
            case 'users':
                this.loadUsers();
                break;
            case 'ads':
                this.loadAds();
                break;
            case 'earnings':
                this.loadEarnings();
                break;
            case 'withdrawals':
                this.loadWithdrawals();
                break;
            case 'settings':
                this.loadSettings();
                break;
        }
    }
    
    // Load dashboard data
    loadDashboardData() {
        const users = Auth.getUsers();
        const ads = AdManager.getAllAds();
        const platformStats = this.getPlatformStats();
        
        // Update statistics
        document.getElementById('totalUsers').textContent = users.length;
        document.getElementById('totalAds').textContent = ads.filter(ad => ad.status === 'active').length;
        document.getElementById('totalViews').textContent = platformStats.totalViews.toLocaleString();
        document.getElementById('totalEarnings').textContent = this.formatCurrency(platformStats.totalEarnings);
        
        // Update growth indicators
        document.getElementById('userGrowth').textContent = '+12%';
        document.getElementById('adsChange').textContent = '+5';
        document.getElementById('viewsGrowth').textContent = '+8%';
        document.getElementById('earningsGrowth').textContent = '+15%';
        
        this.loadRecentActivities();
        this.loadTopAds();
    }
    
    // Load recent activities
    loadRecentActivities() {
        const activities = this.getRecentAdminActivities();
        const container = document.getElementById('adminActivities');
        
        if (!container) return;
        
        container.innerHTML = activities.map(activity => `
            <div class="activity-item">
                <div class="activity-icon">
                    <i class="fas ${activity.icon}"></i>
                </div>
                <div class="activity-content">
                    <p>${activity.description}</p>
                    <small>${activity.timestamp}</small>
                </div>
            </div>
        `).join('');
    }
    
    // Load top performing ads
    loadTopAds() {
        const ads = AdManager.getAllAds()
            .filter(ad => ad.status === 'active')
            .sort((a, b) => (b.views || 0) - (a.views || 0))
            .slice(0, 5);
        
        const container = document.getElementById('topAds');
        if (!container) return;
        
        container.innerHTML = ads.map(ad => `
            <div class="top-ad-item">
                <div class="top-ad-info">
                    <h4>${ad.title}</h4>
                    <small>${ad.category}</small>
                </div>
                <div class="top-ad-stats">
                    <div class="views">${(ad.views || 0).toLocaleString()} views</div>
                    <div class="earning">${this.formatCurrency(ad.earning)} per view</div>
                </div>
            </div>
        `).join('');
    }
    
    // Load users
    loadUsers() {
        const users = Auth.getUsers();
        const tbody = document.getElementById('usersTable');
        
        if (!tbody) return;
        
        tbody.innerHTML = users.map(user => `
            <tr>
                <td>
                    <div class="user-profile-cell">
                        <div class="user-avatar-small">
                            ${user.firstName.charAt(0)}${user.lastName.charAt(0)}
                        </div>
                        <div class="user-info">
                            <h5>${user.firstName} ${user.lastName}</h5>
                            <small>ID: ${user.id}</small>
                        </div>
                    </div>
                </td>
                <td>${user.email}</td>
                <td>${new Date(user.joinDate).toLocaleDateString()}</td>
                <td>${this.formatCurrency(this.getUserTotalEarnings(user.email))}</td>
                <td><span class="status ${user.status}">${user.status}</span></td>
                <td>
                    <div class="table-actions">
                        <button class="action-btn-small edit" onclick="AdminPanel.editUser('${user.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn-small delete" onclick="AdminPanel.deleteUser('${user.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }
    
    // Load ads
    loadAds() {
        const ads = AdManager.getAllAds();
        const tbody = document.getElementById('adsTable');
        
        if (!tbody) return;
        
        tbody.innerHTML = ads.map(ad => `
            <tr>
                <td>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <i class="fas ${ad.icon}" style="color: var(--primary-color);"></i>
                        ${ad.title}
                    </div>
                </td>
                <td>${ad.category}</td>
                <td>${ad.duration}s</td>
                <td>${this.formatCurrency(ad.earning)}</td>
                <td>${(ad.views || 0).toLocaleString()}</td>
                <td><span class="status ${ad.status}">${ad.status}</span></td>
                <td>
                    <div class="table-actions">
                        <button class="action-btn-small edit" onclick="AdminPanel.editAd('${ad.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn-small delete" onclick="AdminPanel.deleteAd('${ad.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }
    
    // Load earnings data
    loadEarnings() {
        const earnings = this.getAllEarnings();
        
        // Update overview
        const today = new Date().toDateString();
        const thisMonth = new Date().getMonth();
        
        const todayEarnings = earnings.filter(e => new Date(e.date).toDateString() === today)
            .reduce((sum, e) => sum + e.amount, 0);
        
        const monthEarnings = earnings.filter(e => new Date(e.date).getMonth() === thisMonth)
            .reduce((sum, e) => sum + e.amount, 0);
        
        const lifetimeEarnings = earnings.reduce((sum, e) => sum + e.amount, 0);
        
        document.getElementById('todayEarnings').textContent = this.formatCurrency(todayEarnings);
        document.getElementById('monthEarnings').textContent = this.formatCurrency(monthEarnings);
        document.getElementById('lifetimeEarnings').textContent = this.formatCurrency(lifetimeEarnings);
        
        // Load earnings table
        this.loadEarningsTable(earnings);
    }
    
    // Load earnings table
    loadEarningsTable(earnings) {
        const tbody = document.getElementById('earningsTable');
        if (!tbody) return;
        
        tbody.innerHTML = earnings.slice(0, 50).map(earning => `
            <tr>
                <td>${earning.userName}</td>
                <td>${earning.adTitle}</td>
                <td>${this.formatCurrency(earning.amount)}</td>
                <td>${new Date(earning.date).toLocaleString()}</td>
                <td><span class="status ${earning.status}">${earning.status}</span></td>
            </tr>
        `).join('');
    }
    
    // Load withdrawals
    loadWithdrawals() {
        const withdrawals = this.getAllWithdrawals();
        
        // Update stats
        const pending = withdrawals.filter(w => w.status === 'pending').length;
        const approved = withdrawals.filter(w => w.status === 'approved').length;
        const totalAmount = withdrawals.reduce((sum, w) => sum + w.amount, 0);
        
        document.getElementById('pendingWithdrawals').textContent = pending;
        document.getElementById('approvedWithdrawals').textContent = approved;
        document.getElementById('totalWithdrawalAmount').textContent = this.formatCurrency(totalAmount);
        
        // Load withdrawals table
        const tbody = document.getElementById('withdrawalsTable');
        if (!tbody) return;
        
        tbody.innerHTML = withdrawals.map(withdrawal => `
            <tr>
                <td>${withdrawal.userName}</td>
                <td>${this.formatCurrency(withdrawal.amount)}</td>
                <td>${withdrawal.method}</td>
                <td>${new Date(withdrawal.requestDate).toLocaleDateString()}</td>
                <td><span class="status ${withdrawal.status}">${withdrawal.status}</span></td>
                <td>
                    <div class="table-actions">
                        ${withdrawal.status === 'pending' ? `
                            <button class="action-btn-small approve" onclick="AdminPanel.approveWithdrawal('${withdrawal.id}')">
                                <i class="fas fa-check"></i>
                            </button>
                            <button class="action-btn-small delete" onclick="AdminPanel.rejectWithdrawal('${withdrawal.id}')">
                                <i class="fas fa-times"></i>
                            </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
        `).join('');
    }
    
    // Load settings
    loadSettings() {
        const settings = this.getPlatformSettings();
        
        // Load payment settings
        document.getElementById('minWithdrawal').value = settings.minWithdrawal || 5.00;
        document.getElementById('processingTime').value = settings.processingTime || 24;
        document.getElementById('paymentFee').value = settings.paymentFee || 0;
        
        // Load ad settings
        document.getElementById('defaultAdEarning').value = settings.defaultAdEarning || 0.05;
        document.getElementById('maxDailyAds').value = settings.maxDailyAds || 50;
        document.getElementById('minAdDuration').value = settings.minAdDuration || 15;
        
        // Load platform statistics
        this.loadPlatformStats();
    }
    
    // Load platform statistics
    loadPlatformStats() {
        const stats = this.calculatePlatformStats();
        
        document.getElementById('dbSize').textContent = stats.dbSize;
        document.getElementById('cacheSize').textContent = stats.cacheSize;
        document.getElementById('activeSessions').textContent = stats.activeSessions;
        document.getElementById('serverUptime').textContent = stats.uptime;
    }
    
    // Initialize modals
    initializeModals() {
        // User modal
        const userModal = document.getElementById('userModal');
        const closeUserModal = document.getElementById('closeUserModal');
        const cancelUser = document.getElementById('cancelUser');
        
        if (closeUserModal) closeUserModal.addEventListener('click', () => this.closeModal('userModal'));
        if (cancelUser) cancelUser.addEventListener('click', () => this.closeModal('userModal'));
        
        // Ad modal
        const adModal = document.getElementById('adModal');
        const closeAdModal = document.getElementById('closeAdModal');
        const cancelAd = document.getElementById('cancelAd');
        
        if (closeAdModal) closeAdModal.addEventListener('click', () => this.closeModal('adModal'));
        if (cancelAd) cancelAd.addEventListener('click', () => this.closeModal('adModal'));
        
        // Add user button
        const addUserBtn = document.getElementById('addUser');
        if (addUserBtn) {
            addUserBtn.addEventListener('click', () => this.showAddUserModal());
        }
        
        // Add ad button
        const addAdBtn = document.getElementById('addAd');
        if (addAdBtn) {
            addAdBtn.addEventListener('click', () => this.showAddAdModal());
        }
    }
    
    // Show add user modal
    showAddUserModal() {
        document.getElementById('userModalTitle').textContent = 'Add User';
        document.getElementById('userForm').reset();
        this.showModal('userModal');
    }
    
    // Show add ad modal
    showAddAdModal() {
        document.getElementById('adModalTitle').textContent = 'Add Advertisement';
        document.getElementById('adForm').reset();
        this.showModal('adModal');
    }
    
    // Show modal
    showModal(modalId) {
        document.getElementById(modalId).classList.add('show');
    }
    
    // Close modal
    closeModal(modalId) {
        document.getElementById(modalId).classList.remove('show');
    }
    
    // Utility methods
    formatCurrency(amount) {
        return '$' + (amount || 0).toFixed(2);
    }
    
    getUserTotalEarnings(email) {
        const userData = Auth.getUserData(email);
        return userData ? userData.totalEarnings || 0 : 0;
    }
    
    getPlatformStats() {
        const stored = localStorage.getItem('platformStats');
        return stored ? JSON.parse(stored) : {
            totalViews: 125678,
            totalEarnings: 52390
        };
    }
    
    getAllEarnings() {
        // This would normally come from a database
        // For demo purposes, we'll generate some sample data
        const users = Auth.getUsers();
        const earnings = [];
        
        users.forEach(user => {
            const userData = Auth.getUserData(user.email);
            if (userData && userData.earningsHistory) {
                userData.earningsHistory.forEach(earning => {
                    earnings.push({
                        userName: `${user.firstName} ${user.lastName}`,
                        adTitle: earning.description.split(' ')[2] || 'Ad',
                        amount: earning.amount,
                        date: earning.date,
                        status: 'completed'
                    });
                });
            }
        });
        
        return earnings.sort((a, b) => new Date(b.date) - new Date(a.date));
    }
    
    getAllWithdrawals() {
        // This would normally come from a database
        // For demo purposes, return empty array or sample data
        return [];
    }
    
    getPlatformSettings() {
        const stored = localStorage.getItem('platformSettings');
        return stored ? JSON.parse(stored) : {};
    }
    
    calculatePlatformStats() {
        const users = Auth.getUsers();
        const ads = AdManager.getAllAds();
        
        return {
            dbSize: `${Math.round(JSON.stringify(users).length / 1024)}KB`,
            cacheSize: `${Math.round(JSON.stringify(ads).length / 1024)}KB`,
            activeSessions: Math.floor(Math.random() * 50) + 10,
            uptime: '99.9%'
        };
    }
    
    getRecentAdminActivities() {
        // Generate some sample activities
        return [
            {
                icon: 'fa-user-plus',
                description: 'New user registered: demo@example.com',
                timestamp: '2 minutes ago'
            },
            {
                icon: 'fa-tv',
                description: 'New advertisement approved: Tech Product Launch',
                timestamp: '15 minutes ago'
            },
            {
                icon: 'fa-dollar-sign',
                description: 'Withdrawal processed: $25.00',
                timestamp: '1 hour ago'
            },
            {
                icon: 'fa-cog',
                description: 'Platform settings updated',
                timestamp: '2 hours ago'
            }
        ];
    }
    
    // Save methods
    savePaymentSettings() {
        const settings = this.getPlatformSettings();
        settings.minWithdrawal = parseFloat(document.getElementById('minWithdrawal').value);
        settings.processingTime = parseInt(document.getElementById('processingTime').value);
        settings.paymentFee = parseFloat(document.getElementById('paymentFee').value);
        
        localStorage.setItem('platformSettings', JSON.stringify(settings));
        this.showMessage('Payment settings saved successfully', 'success');
    }
    
    saveAdSettings() {
        const settings = this.getPlatformSettings();
        settings.defaultAdEarning = parseFloat(document.getElementById('defaultAdEarning').value);
        settings.maxDailyAds = parseInt(document.getElementById('maxDailyAds').value);
        settings.minAdDuration = parseInt(document.getElementById('minAdDuration').value);
        
        localStorage.setItem('platformSettings', JSON.stringify(settings));
        this.showMessage('Ad settings saved successfully', 'success');
    }
    
    // Platform management methods
    clearCache() {
        if (confirm('Are you sure you want to clear the cache?')) {
            // Simulate cache clearing
            this.showMessage('Cache cleared successfully', 'success');
        }
    }
    
    backupData() {
        const data = {
            users: Auth.getUsers(),
            ads: AdManager.getAllAds(),
            settings: this.getPlatformSettings(),
            timestamp: new Date().toISOString()
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `adearn-backup-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
        
        this.showMessage('Data backup downloaded successfully', 'success');
    }
    
    resetPlatform() {
        if (confirm('Are you sure you want to reset the entire platform? This action cannot be undone.')) {
            if (confirm('This will delete all users, ads, and data. Are you absolutely sure?')) {
                localStorage.clear();
                this.showMessage('Platform reset successfully. Redirecting...', 'success');
                setTimeout(() => {
                    window.location.href = 'admin-login.html';
                }, 2000);
            }
        }
    }
    
    // Filter methods
    filterUsers(searchTerm) {
        const rows = document.querySelectorAll('#usersTable tr');
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm.toLowerCase()) ? '' : 'none';
        });
    }
    
    filterAds(searchTerm) {
        const rows = document.querySelectorAll('#adsTable tr');
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm.toLowerCase()) ? '' : 'none';
        });
    }
    
    filterEarningsHistory() {
        const startDate = document.getElementById('earningsStartDate').value;
        const endDate = document.getElementById('earningsEndDate').value;
        
        if (!startDate || !endDate) {
            this.showMessage('Please select both start and end dates', 'warning');
            return;
        }
        
        const earnings = this.getAllEarnings().filter(earning => {
            const earningDate = new Date(earning.date).toDateString();
            return earningDate >= new Date(startDate).toDateString() && 
                   earningDate <= new Date(endDate).toDateString();
        });
        
        this.loadEarningsTable(earnings);
        this.showMessage(`Filtered ${earnings.length} earnings records`, 'success');
    }
    
    // Show message
    showMessage(text, type = 'info') {
        let message = document.getElementById('message');
        if (!message) {
            message = document.createElement('div');
            message.id = 'message';
            message.className = 'message';
            document.body.appendChild(message);
        }
        
        message.textContent = text;
        message.className = `message show ${type}`;
        
        setTimeout(() => {
            message.classList.remove('show');
        }, 3000);
    }
    
    // Logout
    logout() {
        localStorage.removeItem('adminSession');
        sessionStorage.removeItem('adminSession');
        window.location.href = 'admin-login.html';
    }
}

// Static methods for global access
AdminPanel.editUser = function(userId) {
    // Implementation for editing user
    console.log('Edit user:', userId);
};

AdminPanel.deleteUser = function(userId) {
    if (confirm('Are you sure you want to delete this user?')) {
        Auth.deleteUser(userId);
        window.adminPanel.loadUsers();
        window.adminPanel.showMessage('User deleted successfully', 'success');
    }
};

AdminPanel.editAd = function(adId) {
    // Implementation for editing ad
    console.log('Edit ad:', adId);
};

AdminPanel.deleteAd = function(adId) {
    if (confirm('Are you sure you want to delete this ad?')) {
        AdManager.deleteAd(adId);
        window.adminPanel.loadAds();
        window.adminPanel.showMessage('Ad deleted successfully', 'success');
    }
};

AdminPanel.approveWithdrawal = function(withdrawalId) {
    // Implementation for approving withdrawal
    console.log('Approve withdrawal:', withdrawalId);
};

AdminPanel.rejectWithdrawal = function(withdrawalId) {
    if (confirm('Are you sure you want to reject this withdrawal?')) {
        // Implementation for rejecting withdrawal
        console.log('Reject withdrawal:', withdrawalId);
    }
};

// Initialize admin panel when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.adminPanel = new AdminPanel();
});
