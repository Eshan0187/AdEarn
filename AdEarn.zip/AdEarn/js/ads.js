// Advertisement management system for AdEarn platform
class AdManager {
    constructor() {
        this.adsKey = 'adEarnAds';
        this.initializeAds();
    }
    
    // Initialize ads with sample data
    initializeAds() {
        const existingAds = localStorage.getItem(this.adsKey);
        if (!existingAds) {
            const sampleAds = [
                {
                    id: 'ad1',
                    title: 'Latest Smartphone Launch',
                    description: 'Discover the revolutionary features of the new smartphone that\'s changing everything.',
                    category: 'technology',
                    duration: 30,
                    earning: 0.12,
                    icon: 'fa-mobile-alt',
                    status: 'active',
                    views: 1250,
                    createdAt: new Date().toISOString(),
                    featured: true
                },
                {
                    id: 'ad2',
                    title: 'Fashion Week Collection',
                    description: 'Explore the latest fashion trends from top designers around the world.',
                    category: 'fashion',
                    duration: 25,
                    earning: 0.08,
                    icon: 'fa-tshirt',
                    status: 'active',
                    views: 980,
                    createdAt: new Date().toISOString(),
                    featured: true
                },
                {
                    id: 'ad3',
                    title: 'Gourmet Food Delivery',
                    description: 'Delicious meals from the best restaurants delivered to your door.',
                    category: 'food',
                    duration: 20,
                    earning: 0.06,
                    icon: 'fa-utensils',
                    status: 'active',
                    views: 750,
                    createdAt: new Date().toISOString(),
                    featured: false
                },
                {
                    id: 'ad4',
                    title: 'Dream Vacation Packages',
                    description: 'Book your perfect getaway with exclusive deals on hotels and flights.',
                    category: 'travel',
                    duration: 35,
                    earning: 0.15,
                    icon: 'fa-plane',
                    status: 'active',
                    views: 1520,
                    createdAt: new Date().toISOString(),
                    featured: true
                },
                {
                    id: 'ad5',
                    title: 'Investment Opportunities',
                    description: 'Grow your wealth with smart investment strategies and expert advice.',
                    category: 'finance',
                    duration: 40,
                    earning: 0.20,
                    icon: 'fa-chart-line',
                    status: 'active',
                    views: 2100,
                    createdAt: new Date().toISOString(),
                    featured: true
                },
                {
                    id: 'ad6',
                    title: 'Fitness Equipment Sale',
                    description: 'Get in shape with professional-grade fitness equipment at amazing prices.',
                    category: 'health',
                    duration: 28,
                    earning: 0.10,
                    icon: 'fa-dumbbell',
                    status: 'active',
                    views: 890,
                    createdAt: new Date().toISOString(),
                    featured: false
                },
                {
                    id: 'ad7',
                    title: 'Smart Home Solutions',
                    description: 'Transform your home with intelligent automation and security systems.',
                    category: 'technology',
                    duration: 32,
                    earning: 0.14,
                    icon: 'fa-home',
                    status: 'active',
                    views: 1340,
                    createdAt: new Date().toISOString(),
                    featured: false
                },
                {
                    id: 'ad8',
                    title: 'Premium Coffee Subscription',
                    description: 'Enjoy the finest coffee beans from around the world delivered monthly.',
                    category: 'food',
                    duration: 22,
                    earning: 0.07,
                    icon: 'fa-coffee',
                    status: 'active',
                    views: 670,
                    createdAt: new Date().toISOString(),
                    featured: false
                },
                {
                    id: 'ad9',
                    title: 'Online Learning Platform',
                    description: 'Master new skills with expert-led courses and interactive learning.',
                    category: 'technology',
                    duration: 38,
                    earning: 0.16,
                    icon: 'fa-graduation-cap',
                    status: 'active',
                    views: 1800,
                    createdAt: new Date().toISOString(),
                    featured: true
                },
                {
                    id: 'ad10',
                    title: 'Luxury Watch Collection',
                    description: 'Discover timeless elegance with our exclusive collection of luxury timepieces.',
                    category: 'fashion',
                    duration: 26,
                    earning: 0.11,
                    icon: 'fa-clock',
                    status: 'active',
                    views: 1150,
                    createdAt: new Date().toISOString(),
                    featured: false
                }
            ];
            
            localStorage.setItem(this.adsKey, JSON.stringify(sampleAds));
        }
    }
    
    // Get all ads
    getAllAds() {
        const ads = localStorage.getItem(this.adsKey);
        return ads ? JSON.parse(ads) : [];
    }
    
    // Get active ads
    getActiveAds() {
        return this.getAllAds().filter(ad => ad.status === 'active');
    }
    
    // Get featured ads
    getFeaturedAds(limit = 6) {
        return this.getActiveAds()
            .filter(ad => ad.featured)
            .slice(0, limit);
    }
    
    // Get available ads for user (with optional filtering)
    getAvailableAds(filters = {}) {
        let ads = this.getActiveAds();
        
        // Apply category filter
        if (filters.category) {
            ads = ads.filter(ad => ad.category === filters.category);
        }
        
        // Apply earnings filter
        if (filters.earnings) {
            switch(filters.earnings) {
                case 'low':
                    ads = ads.filter(ad => ad.earning <= 0.05);
                    break;
                case 'medium':
                    ads = ads.filter(ad => ad.earning > 0.05 && ad.earning <= 0.15);
                    break;
                case 'high':
                    ads = ads.filter(ad => ad.earning > 0.15);
                    break;
            }
        }
        
        // Apply duration filter
        if (filters.duration) {
            switch(filters.duration) {
                case 'short':
                    ads = ads.filter(ad => ad.duration <= 30);
                    break;
                case 'medium':
                    ads = ads.filter(ad => ad.duration > 30 && ad.duration <= 60);
                    break;
                case 'long':
                    ads = ads.filter(ad => ad.duration > 60);
                    break;
            }
        }
        
        // Sort by earnings (highest first) by default
        return ads.sort((a, b) => b.earning - a.earning);
    }
    
    // Get ad by ID
    getAdById(adId) {
        return this.getAllAds().find(ad => ad.id === adId);
    }
    
    // Add new ad
    addAd(adData) {
        const ads = this.getAllAds();
        const newAd = {
            id: 'ad_' + Date.now(),
            ...adData,
            views: 0,
            status: adData.status || 'active',
            createdAt: new Date().toISOString()
        };
        
        ads.push(newAd);
        localStorage.setItem(this.adsKey, JSON.stringify(ads));
        return newAd;
    }
    
    // Update ad
    updateAd(adId, updates) {
        const ads = this.getAllAds();
        const adIndex = ads.findIndex(ad => ad.id === adId);
        
        if (adIndex === -1) {
            return { success: false, message: 'Ad not found' };
        }
        
        ads[adIndex] = { ...ads[adIndex], ...updates };
        localStorage.setItem(this.adsKey, JSON.stringify(ads));
        
        return { success: true, ad: ads[adIndex] };
    }
    
    // Delete ad
    deleteAd(adId) {
        const ads = this.getAllAds();
        const filteredAds = ads.filter(ad => ad.id !== adId);
        localStorage.setItem(this.adsKey, JSON.stringify(filteredAds));
        
        return { success: true };
    }
    
    // Complete ad viewing (user watched the full ad)
    completeAd(adId) {
        if (!Auth.isLoggedIn()) {
            return { success: false, message: 'Not logged in' };
        }
        
        const ad = this.getAdById(adId);
        if (!ad) {
            return { success: false, message: 'Ad not found' };
        }
        
        const currentUser = Auth.getCurrentUser();
        
        // Check if user has already watched this ad today
        if (this.hasWatchedAdToday(currentUser.email, adId)) {
            return { success: false, message: 'You have already watched this ad today' };
        }
        
        // Check daily ad limit
        const todayCount = this.getTodayAdCount(currentUser.email);
        const maxDailyAds = this.getMaxDailyAds();
        
        if (todayCount >= maxDailyAds) {
            return { success: false, message: `Daily ad limit of ${maxDailyAds} reached` };
        }
        
        // Record ad view
        this.recordAdView(currentUser.email, adId);
        
        // Update ad view count
        this.incrementAdViews(adId);
        
        // Update user earnings
        Auth.updateBalance(ad.earning, 'earning', `Watched ad: ${ad.title}`);
        
        // Update user stats
        const userData = Auth.getUserData();
        userData.adsWatched = (userData.adsWatched || 0) + 1;
        userData.timeSpent = (userData.timeSpent || 0) + Math.round(ad.duration / 60); // Convert to minutes
        Auth.saveUserData(userData);
        
        return { 
            success: true, 
            earning: ad.earning,
            message: `You earned ${this.formatCurrency(ad.earning)}!`
        };
    }
    
    // Check if user has watched specific ad today
    hasWatchedAdToday(userEmail, adId) {
        const viewsKey = `adViews_${userEmail}`;
        const views = JSON.parse(localStorage.getItem(viewsKey) || '[]');
        const today = new Date().toDateString();
        
        return views.some(view => 
            view.adId === adId && 
            new Date(view.date).toDateString() === today
        );
    }
    
    // Get today's ad count for user
    getTodayAdCount(userEmail) {
        const viewsKey = `adViews_${userEmail}`;
        const views = JSON.parse(localStorage.getItem(viewsKey) || '[]');
        const today = new Date().toDateString();
        
        return views.filter(view => 
            new Date(view.date).toDateString() === today
        ).length;
    }
    
    // Record ad view
    recordAdView(userEmail, adId) {
        const viewsKey = `adViews_${userEmail}`;
        const views = JSON.parse(localStorage.getItem(viewsKey) || '[]');
        
        views.push({
            adId: adId,
            date: new Date().toISOString(),
            timestamp: Date.now()
        });
        
        // Keep only last 30 days of views
        const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
        const recentViews = views.filter(view => view.timestamp > thirtyDaysAgo);
        
        localStorage.setItem(viewsKey, JSON.stringify(recentViews));
    }
    
    // Increment ad view count
    incrementAdViews(adId) {
        const ads = this.getAllAds();
        const adIndex = ads.findIndex(ad => ad.id === adId);
        
        if (adIndex !== -1) {
            ads[adIndex].views = (ads[adIndex].views || 0) + 1;
            localStorage.setItem(this.adsKey, JSON.stringify(ads));
        }
    }
    
    // Get max daily ads setting
    getMaxDailyAds() {
        const settings = JSON.parse(localStorage.getItem('platformSettings') || '{}');
        return settings.maxDailyAds || 50;
    }
    
    // Get user's ad viewing history
    getUserAdHistory(userEmail) {
        const viewsKey = `adViews_${userEmail}`;
        const views = JSON.parse(localStorage.getItem(viewsKey) || '[]');
        
        return views.map(view => {
            const ad = this.getAdById(view.adId);
            return {
                ...view,
                adTitle: ad ? ad.title : 'Unknown Ad',
                earning: ad ? ad.earning : 0
            };
        }).sort((a, b) => new Date(b.date) - new Date(a.date));
    }
    
    // Get ads by category
    getAdsByCategory(category) {
        return this.getActiveAds().filter(ad => ad.category === category);
    }
    
    // Search ads
    searchAds(query) {
        const searchTerm = query.toLowerCase();
        return this.getActiveAds().filter(ad => 
            ad.title.toLowerCase().includes(searchTerm) ||
            ad.description.toLowerCase().includes(searchTerm) ||
            ad.category.toLowerCase().includes(searchTerm)
        );
    }
    
    // Get top performing ads
    getTopPerformingAds(limit = 10) {
        return this.getActiveAds()
            .sort((a, b) => (b.views || 0) - (a.views || 0))
            .slice(0, limit);
    }
    
    // Get ads statistics
    getAdsStatistics() {
        const ads = this.getAllAds();
        const activeAds = ads.filter(ad => ad.status === 'active');
        
        return {
            total: ads.length,
            active: activeAds.length,
            paused: ads.filter(ad => ad.status === 'paused').length,
            archived: ads.filter(ad => ad.status === 'archived').length,
            totalViews: ads.reduce((sum, ad) => sum + (ad.views || 0), 0),
            totalEarnings: ads.reduce((sum, ad) => sum + (ad.views || 0) * ad.earning, 0),
            categories: this.getCategoryStatistics(activeAds)
        };
    }
    
    // Get category statistics
    getCategoryStatistics(ads) {
        const categories = {};
        ads.forEach(ad => {
            if (!categories[ad.category]) {
                categories[ad.category] = {
                    count: 0,
                    totalViews: 0,
                    totalEarnings: 0
                };
            }
            categories[ad.category].count++;
            categories[ad.category].totalViews += ad.views || 0;
            categories[ad.category].totalEarnings += (ad.views || 0) * ad.earning;
        });
        return categories;
    }
    
    // Format currency
    formatCurrency(amount) {
        return '$' + (amount || 0).toFixed(2);
    }
    
    // Validate ad data
    validateAdData(adData) {
        const errors = [];
        
        if (!adData.title || adData.title.trim().length < 3) {
            errors.push('Title must be at least 3 characters long');
        }
        
        if (!adData.description || adData.description.trim().length < 10) {
            errors.push('Description must be at least 10 characters long');
        }
        
        if (!adData.category) {
            errors.push('Category is required');
        }
        
        if (!adData.duration || adData.duration < 15 || adData.duration > 300) {
            errors.push('Duration must be between 15 and 300 seconds');
        }
        
        if (!adData.earning || adData.earning < 0.01 || adData.earning > 1.00) {
            errors.push('Earning must be between $0.01 and $1.00');
        }
        
        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }
    
    // Get recommended ads for user
    getRecommendedAds(userEmail, limit = 10) {
        // Get user's viewing history to determine preferences
        const history = this.getUserAdHistory(userEmail);
        const categoryPreferences = {};
        
        // Calculate category preferences based on viewing history
        history.forEach(view => {
            const ad = this.getAdById(view.adId);
            if (ad) {
                categoryPreferences[ad.category] = (categoryPreferences[ad.category] || 0) + 1;
            }
        });
        
        // Get all available ads
        let availableAds = this.getAvailableAds();
        
        // Sort by user preferences and earning potential
        availableAds.sort((a, b) => {
            const aPreference = categoryPreferences[a.category] || 0;
            const bPreference = categoryPreferences[b.category] || 0;
            
            // Weight: 70% preference, 30% earning
            const aScore = (aPreference * 0.7) + (a.earning * 0.3);
            const bScore = (bPreference * 0.7) + (b.earning * 0.3);
            
            return bScore - aScore;
        });
        
        return availableAds.slice(0, limit);
    }
    
    // Generate ad analytics
    generateAdAnalytics(adId, days = 7) {
        const ad = this.getAdById(adId);
        if (!ad) return null;
        
        // This would normally fetch from a database
        // For demo purposes, generate sample analytics
        const analytics = {
            adId: adId,
            title: ad.title,
            totalViews: ad.views || 0,
            totalEarnings: (ad.views || 0) * ad.earning,
            averageViewTime: ad.duration * 0.85, // Assume 85% completion rate
            clickThroughRate: Math.random() * 0.05 + 0.02, // 2-7% CTR
            dailyViews: [],
            demographics: {
                byCountry: {
                    'US': 35,
                    'CA': 15,
                    'GB': 12,
                    'AU': 8,
                    'DE': 7,
                    'Others': 23
                },
                byAge: {
                    '18-24': 28,
                    '25-34': 35,
                    '35-44': 22,
                    '45-54': 10,
                    '55+': 5
                }
            }
        };
        
        // Generate daily views for the past week
        for (let i = days - 1; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            analytics.dailyViews.push({
                date: date.toISOString().split('T')[0],
                views: Math.floor(Math.random() * 50) + 10,
                earnings: (Math.floor(Math.random() * 50) + 10) * ad.earning
            });
        }
        
        return analytics;
    }
}

// Create global AdManager instance (only if it doesn't exist)
if (typeof window.AdManager === 'undefined') {
    const AdManager = new AdManager();
    window.AdManager = AdManager;
}
