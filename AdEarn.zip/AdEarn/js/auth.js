// Authentication system for AdEarn platform
class AuthSystem {
    constructor() {
        this.currentUser = null;
        this.sessionKey = 'adEarnSession';
        this.usersKey = 'adEarnUsers';
        this.loadSession();
    }
    
    // Initialize demo users if they don't exist
    initializeDemoUsers() {
        const existingUsers = localStorage.getItem(this.usersKey);
        if (!existingUsers) {
            const demoUsers = [
                {
                    id: 'user1',
                    email: 'user@demo.com',
                    password: 'demo123', // In real app, this would be hashed
                    firstName: 'Demo',
                    lastName: 'User',
                    country: 'US',
                    joinDate: new Date().toISOString(),
                    status: 'active',
                    emailVerified: true,
                    newsletter: true
                }
            ];
            localStorage.setItem(this.usersKey, JSON.stringify(demoUsers));
        }
    }
    
    // Load session from localStorage
    loadSession() {
        this.initializeDemoUsers();
        
        const sessionData = localStorage.getItem(this.sessionKey);
        if (sessionData) {
            try {
                const session = JSON.parse(sessionData);
                const now = new Date().getTime();
                
                // Check if session is still valid (24 hours)
                if (now - session.timestamp < 24 * 60 * 60 * 1000) {
                    this.currentUser = session.user;
                } else {
                    this.clearSession();
                }
            } catch (error) {
                console.error('Error loading session:', error);
                this.clearSession();
            }
        }
    }
    
    // Save session to localStorage
    saveSession(user, rememberMe = false) {
        const sessionData = {
            user: user,
            timestamp: new Date().getTime(),
            rememberMe: rememberMe
        };
        
        localStorage.setItem(this.sessionKey, JSON.stringify(sessionData));
        this.currentUser = user;
    }
    
    // Clear session
    clearSession() {
        localStorage.removeItem(this.sessionKey);
        this.currentUser = null;
    }
    
    // Register new user
    register(userData) {
        try {
            // Validate required fields
            if (!userData.firstName || !userData.lastName || !userData.email || !userData.password) {
                return { success: false, message: 'All fields are required' };
            }
            
            // Validate email format
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(userData.email)) {
                return { success: false, message: 'Invalid email format' };
            }
            
            // Validate password strength
            if (userData.password.length < 6) {
                return { success: false, message: 'Password must be at least 6 characters long' };
            }
            
            // Check if email already exists
            const users = this.getUsers();
            const existingUser = users.find(user => user.email.toLowerCase() === userData.email.toLowerCase());
            
            if (existingUser) {
                return { success: false, message: 'Email address already registered' };
            }
            
            // Create new user
            const newUser = {
                id: 'user_' + Date.now(),
                email: userData.email.toLowerCase(),
                password: userData.password, // In real app, hash this
                firstName: userData.firstName,
                lastName: userData.lastName,
                country: userData.country,
                newsletter: userData.newsletter || false,
                joinDate: new Date().toISOString(),
                status: 'active',
                emailVerified: true, // Simulated as verified
                lastLogin: new Date().toISOString()
            };
            
            // Save user
            users.push(newUser);
            localStorage.setItem(this.usersKey, JSON.stringify(users));
            
            // Initialize user data
            this.initializeUserData(newUser);
            
            // Auto-login after registration
            this.saveSession(newUser, false);
            
            return { success: true, user: newUser };
            
        } catch (error) {
            console.error('Registration error:', error);
            return { success: false, message: 'Registration failed. Please try again.' };
        }
    }
    
    // Login user
    login(email, password, rememberMe = false) {
        try {
            const users = this.getUsers();
            const user = users.find(u => 
                u.email.toLowerCase() === email.toLowerCase() && 
                u.password === password
            );
            
            if (!user) {
                return { success: false, message: 'Invalid email or password' };
            }
            
            if (user.status !== 'active') {
                return { success: false, message: 'Account is suspended or banned' };
            }
            
            // Update last login
            user.lastLogin = new Date().toISOString();
            const userIndex = users.findIndex(u => u.id === user.id);
            users[userIndex] = user;
            localStorage.setItem(this.usersKey, JSON.stringify(users));
            
            // Save session
            this.saveSession(user, rememberMe);
            
            return { success: true, user: user };
            
        } catch (error) {
            console.error('Login error:', error);
            return { success: false, message: 'Login failed. Please try again.' };
        }
    }
    
    // Logout user
    logout() {
        this.clearSession();
        return { success: true };
    }
    
    // Check if user is logged in
    isLoggedIn() {
        return this.currentUser !== null;
    }
    
    // Get current user
    getCurrentUser() {
        return this.currentUser;
    }
    
    // Get all users (admin function)
    getUsers() {
        const users = localStorage.getItem(this.usersKey);
        return users ? JSON.parse(users) : [];
    }
    
    // Update user profile
    updateProfile(updates) {
        if (!this.currentUser) {
            return { success: false, message: 'Not logged in' };
        }
        
        try {
            const users = this.getUsers();
            const userIndex = users.findIndex(u => u.id === this.currentUser.id);
            
            if (userIndex === -1) {
                return { success: false, message: 'User not found' };
            }
            
            // Update user data
            const updatedUser = { ...users[userIndex], ...updates };
            users[userIndex] = updatedUser;
            
            // Save to localStorage
            localStorage.setItem(this.usersKey, JSON.stringify(users));
            
            // Update current session
            this.currentUser = updatedUser;
            this.saveSession(updatedUser, true);
            
            return { success: true, user: updatedUser };
            
        } catch (error) {
            console.error('Profile update error:', error);
            return { success: false, message: 'Failed to update profile' };
        }
    }
    
    // Change password
    changePassword(currentPassword, newPassword) {
        if (!this.currentUser) {
            return { success: false, message: 'Not logged in' };
        }
        
        if (this.currentUser.password !== currentPassword) {
            return { success: false, message: 'Current password is incorrect' };
        }
        
        if (newPassword.length < 6) {
            return { success: false, message: 'New password must be at least 6 characters long' };
        }
        
        return this.updateProfile({ password: newPassword });
    }
    
    // Initialize user data for new users
    initializeUserData(user) {
        const userData = {
            balance: 0,
            totalEarnings: 0,
            adsWatched: 0,
            todayEarnings: 0,
            timeSpent: 0,
            recentActivities: [
                {
                    icon: 'fa-user-plus',
                    description: 'Welcome to AdEarn! Account created successfully.',
                    timestamp: new Date().toLocaleString(),
                    type: 'info'
                }
            ],
            earningsChart: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                data: [0, 0, 0, 0, 0, 0, 0]
            },
            preferences: {
                emailNotifications: true,
                newsletter: user.newsletter || false,
                soundEffects: true
            },
            withdrawalHistory: [],
            earningsHistory: []
        };
        
        localStorage.setItem(`userData_${user.email}`, JSON.stringify(userData));
    }
    
    // Get user data
    getUserData(email = null) {
        const userEmail = email || (this.currentUser ? this.currentUser.email : null);
        if (!userEmail) return null;
        
        const userData = localStorage.getItem(`userData_${userEmail}`);
        return userData ? JSON.parse(userData) : null;
    }
    
    // Save user data
    saveUserData(data, email = null) {
        const userEmail = email || (this.currentUser ? this.currentUser.email : null);
        if (!userEmail) return false;
        
        const existing = this.getUserData(userEmail) || {};
        const updated = { ...existing, ...data };
        
        localStorage.setItem(`userData_${userEmail}`, JSON.stringify(updated));
        return true;
    }
    
    // Add activity to user's recent activities
    addActivity(activity) {
        if (!this.currentUser) return;
        
        const userData = this.getUserData();
        if (!userData) return;
        
        userData.recentActivities = userData.recentActivities || [];
        userData.recentActivities.unshift({
            ...activity,
            timestamp: new Date().toLocaleString()
        });
        
        // Keep only last 10 activities
        userData.recentActivities = userData.recentActivities.slice(0, 10);
        
        this.saveUserData(userData);
    }
    
    // Update user balance
    updateBalance(amount, type = 'earning', description = '') {
        if (!this.currentUser) return false;
        
        const userData = this.getUserData();
        if (!userData) return false;
        
        userData.balance = (userData.balance || 0) + amount;
        userData.totalEarnings = (userData.totalEarnings || 0) + (type === 'earning' ? amount : 0);
        userData.todayEarnings = (userData.todayEarnings || 0) + (type === 'earning' ? amount : 0);
        
        // Add to earnings history
        userData.earningsHistory = userData.earningsHistory || [];
        userData.earningsHistory.unshift({
            amount: amount,
            type: type,
            description: description,
            date: new Date().toISOString(),
            balance: userData.balance
        });
        
        // Add activity
        this.addActivity({
            icon: type === 'earning' ? 'fa-plus-circle' : 'fa-minus-circle',
            description: description || `${type === 'earning' ? 'Earned' : 'Spent'} ${this.formatCurrency(Math.abs(amount))}`,
            amount: amount,
            type: type
        });
        
        this.saveUserData(userData);
        return true;
    }
    
    // Format currency
    formatCurrency(amount) {
        return '$' + (amount || 0).toFixed(2);
    }
    
    // Delete user (admin function)
    deleteUser(userId) {
        try {
            const users = this.getUsers();
            const filteredUsers = users.filter(user => user.id !== userId);
            localStorage.setItem(this.usersKey, JSON.stringify(filteredUsers));
            
            // Also remove user data
            const user = users.find(u => u.id === userId);
            if (user) {
                localStorage.removeItem(`userData_${user.email}`);
            }
            
            return { success: true };
        } catch (error) {
            console.error('Delete user error:', error);
            return { success: false, message: 'Failed to delete user' };
        }
    }
    
    // Update user status (admin function)
    updateUserStatus(userId, status) {
        try {
            const users = this.getUsers();
            const userIndex = users.findIndex(u => u.id === userId);
            
            if (userIndex === -1) {
                return { success: false, message: 'User not found' };
            }
            
            users[userIndex].status = status;
            localStorage.setItem(this.usersKey, JSON.stringify(users));
            
            return { success: true };
        } catch (error) {
            console.error('Update user status error:', error);
            return { success: false, message: 'Failed to update user status' };
        }
    }
}

// Create global Auth instance
const Auth = new AuthSystem();

// Export for use in other modules
window.Auth = Auth;
