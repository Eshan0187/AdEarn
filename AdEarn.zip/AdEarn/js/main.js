// Main JavaScript functionality for the homepage
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the application
    initializeApp();
    
    // Load featured ads
    loadFeaturedAds();
    
    // Update navigation based on authentication state
    updateNavigation();
    
    // Setup event listeners
    setupEventListeners();
    
    // Animate statistics
    animateStats();
});

// Initialize application
function initializeApp() {
    // Check if user is already logged in
    if (Auth.isLoggedIn()) {
        updateNavigation();
        updateUserBalance();
    }
    
    // Initialize demo data if not exists
    initializeDemoData();
}

// Setup event listeners
function setupEventListeners() {
    // Mobile navigation toggle
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (navToggle) {
        navToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }
    
    // Category card interactions
    document.querySelectorAll('.category-card').forEach(card => {
        card.addEventListener('click', function() {
            const category = this.dataset.category;
            if (Auth.isLoggedIn()) {
                window.location.href = `dashboard.html#ads?category=${category}`;
            } else {
                window.location.href = 'register.html';
            }
        });
    });
    
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            Auth.logout();
            updateNavigation();
            showMessage('Logged out successfully', 'success');
        });
    }
}

// Load featured ads on homepage
function loadFeaturedAds() {
    const featuredAdsContainer = document.getElementById('featuredAds');
    if (!featuredAdsContainer) return;
    
    const featuredAds = AdManager.getFeaturedAds(6);
    
    featuredAdsContainer.innerHTML = featuredAds.map(ad => `
        <div class="ad-card" data-ad-id="${ad.id}">
            <div class="ad-image">
                <i class="fas ${ad.icon}"></i>
            </div>
            <div class="ad-info">
                <h4>${ad.title}</h4>
                <p>${ad.description}</p>
                <div class="ad-meta">
                    <span class="ad-category">${capitalizeFirst(ad.category)}</span>
                    <span class="ad-duration">${ad.duration}s</span>
                    <span class="ad-earning">+${formatCurrency(ad.earning)}</span>
                </div>
            </div>
            <button class="btn btn-primary watch-ad-btn" onclick="handleWatchAd('${ad.id}')">
                <i class="fas fa-play"></i>
                ${Auth.isLoggedIn() ? 'Watch Ad' : 'Sign Up to Watch'}
            </button>
        </div>
    `).join('');
}

// Handle watch ad button click
function handleWatchAd(adId) {
    if (!Auth.isLoggedIn()) {
        window.location.href = 'register.html';
        return;
    }
    
    window.location.href = `dashboard.html#ads?watch=${adId}`;
}

// Update navigation based on authentication state
function updateNavigation() {
    const navAuth = document.getElementById('navAuth');
    const navUser = document.getElementById('navUser');
    
    if (!navAuth || !navUser) return;
    
    if (Auth.isLoggedIn()) {
        navAuth.classList.add('hidden');
        navUser.classList.remove('hidden');
        updateUserBalance();
    } else {
        navAuth.classList.remove('hidden');
        navUser.classList.add('hidden');
    }
}

// Update user balance display
function updateUserBalance() {
    const balanceElement = document.getElementById('userBalance');
    if (!balanceElement) return;
    
    const currentUser = Auth.getCurrentUser();
    if (currentUser) {
        const userData = getUserData(currentUser.email);
        balanceElement.textContent = formatCurrency(userData.balance || 0);
    }
}

// Get user data from localStorage
function getUserData(email) {
    const defaultData = {
        balance: 0,
        totalEarnings: 0,
        adsWatched: 0,
        todayEarnings: 0,
        timeSpent: 0
    };
    
    const stored = localStorage.getItem(`userData_${email}`);
    return stored ? { ...defaultData, ...JSON.parse(stored) } : defaultData;
}

// Animate statistics on homepage
function animateStats() {
    const stats = [
        { id: 'totalUsers', target: 5247 },
        { id: 'totalEarnings', target: 52390, prefix: '$' },
        { id: 'totalAds', target: 1234 }
    ];
    
    stats.forEach(stat => {
        const element = document.getElementById(stat.id);
        if (element) {
            animateNumber(element, stat.target, stat.prefix);
        }
    });
}

// Animate number counting effect
function animateNumber(element, target, prefix = '') {
    let current = 0;
    const increment = target / 100;
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        
        const value = Math.floor(current);
        element.textContent = prefix + (prefix === '$' ? formatNumber(value) : value.toLocaleString());
    }, 20);
}

// Format number for display
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

// Format currency
function formatCurrency(amount) {
    return '$' + (amount || 0).toFixed(2);
}

// Capitalize first letter
function capitalizeFirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

// Initialize demo data if not exists
function initializeDemoData() {
    // Initialize platform statistics if not exists
    if (!localStorage.getItem('platformStats')) {
        const platformStats = {
            totalUsers: 5247,
            totalEarnings: 52390,
            totalAds: 1234,
            totalViews: 125678,
            lastUpdated: new Date().toISOString()
        };
        localStorage.setItem('platformStats', JSON.stringify(platformStats));
    }
    
    // Update stats periodically
    updatePlatformStats();
}

// Update platform statistics
function updatePlatformStats() {
    const stats = JSON.parse(localStorage.getItem('platformStats') || '{}');
    const now = new Date();
    const lastUpdate = new Date(stats.lastUpdated || now);
    const hoursSinceUpdate = (now - lastUpdate) / (1000 * 60 * 60);
    
    // Update stats every hour
    if (hoursSinceUpdate >= 1) {
        stats.totalUsers += Math.floor(Math.random() * 10) + 1;
        stats.totalEarnings += Math.floor(Math.random() * 100) + 50;
        stats.totalAds += Math.floor(Math.random() * 5);
        stats.totalViews += Math.floor(Math.random() * 200) + 100;
        stats.lastUpdated = now.toISOString();
        
        localStorage.setItem('platformStats', JSON.stringify(stats));
        
        // Update display
        if (document.getElementById('totalUsers')) {
            document.getElementById('totalUsers').textContent = stats.totalUsers.toLocaleString();
        }
        if (document.getElementById('totalEarnings')) {
            document.getElementById('totalEarnings').textContent = '$' + formatNumber(stats.totalEarnings);
        }
        if (document.getElementById('totalAds')) {
            document.getElementById('totalAds').textContent = stats.totalAds.toLocaleString();
        }
    }
}

// Show message notification
function showMessage(text, type = 'info') {
    // Create message element if it doesn't exist
    let message = document.getElementById('message');
    if (!message) {
        message = document.createElement('div');
        message.id = 'message';
        message.className = 'message';
        document.body.appendChild(message);
    }
    
    message.textContent = text;
    message.className = `message show ${type}`;
    
    setTimeout(() => {
        message.classList.remove('show');
    }, 3000);
}

// Page visibility API for updating stats when page becomes visible
document.addEventListener('visibilitychange', function() {
    if (!document.hidden) {
        updatePlatformStats();
        if (Auth.isLoggedIn()) {
            updateUserBalance();
        }
    }
});

// Handle window resize for responsive adjustments
window.addEventListener('resize', function() {
    // Close mobile menu on resize
    const navMenu = document.querySelector('.nav-menu');
    if (navMenu && window.innerWidth > 768) {
        navMenu.classList.remove('active');
    }
});

// Initialize tooltips and other interactive elements
function initializeTooltips() {
    // Add hover effects to category cards
    document.querySelectorAll('.category-card').forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
}

// Call initialize tooltips when DOM is ready
document.addEventListener('DOMContentLoaded', initializeTooltips);

// Export functions for use in other modules
window.MainApp = {
    updateNavigation,
    updateUserBalance,
    showMessage,
    formatCurrency,
    capitalizeFirst
};
