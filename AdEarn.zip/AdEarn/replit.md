# AdEarn Platform

## Overview

AdEarn is a web-based advertising platform that allows users to earn money by viewing advertisements. The platform features a user-facing interface where registered users can watch ads and accumulate earnings, plus an administrative dashboard for managing users, advertisements, earnings, and withdrawals. The system operates entirely on the frontend using localStorage for data persistence, making it a demonstration platform with client-side data management.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### JavaScript Error Fix (August 11, 2025)
- Fixed AdManager duplicate declaration error that was causing console issues
- Added conditional check to prevent multiple AdManager instances

## Potential Feature Expansions

User requested more ideas for the website. Key enhancement areas identified:
- Gamification system with streaks, badges, and leaderboards
- Enhanced earning opportunities with surveys and referrals
- Smart AI-powered ad recommendations
- Mobile responsiveness and PWA capabilities
- Advanced analytics and insights
- Social features and community building
- Multiple payment methods and instant withdrawals
- Advertiser self-service tools

## System Architecture

### Frontend Architecture
- **Pure HTML/CSS/JavaScript**: No framework dependencies, using vanilla JavaScript for all functionality
- **Component-based Structure**: Organized into logical modules (AuthSystem, AdManager, AdminPanel) that handle specific platform features
- **Responsive Design**: Mobile-first approach using CSS Grid and Flexbox with Font Awesome icons for UI elements
- **Single Page Application Elements**: Dynamic content switching within dashboard and admin interfaces without page reloads

### Authentication & Authorization
- **Client-side Session Management**: Uses localStorage and sessionStorage for persisting user sessions
- **Role-based Access**: Separate authentication flows for regular users and administrators
- **Session Expiration**: Configurable session timeouts (4 hours default, 24 hours with "remember me")
- **Demo User System**: Pre-populated with sample users for testing and demonstration purposes

### Data Storage Strategy
- **Browser localStorage**: Primary data persistence for users, advertisements, earnings, and session data
- **Structured JSON Storage**: Organized data models for users, ads, earnings, and administrative settings
- **Client-side Data Models**: Separate storage keys for different data types (adEarnUsers, adEarnAds, adEarnSession)

### Advertisement System
- **Category-based Organization**: Ads organized by categories (technology, fashion, food, etc.)
- **Earning Calculation**: Each ad has associated earning amounts and viewing duration requirements
- **View Tracking**: System tracks ad views, completion rates, and user engagement metrics
- **Featured Ad System**: Promotional highlighting for specific advertisements

### User Interface Design
- **Multi-page Layout**: Separate pages for authentication, user dashboard, and admin panel
- **Dashboard Navigation**: Sidebar-based navigation with section switching for different user functions
- **Admin Interface**: Comprehensive management panel with user management, ad control, and earnings oversight
- **Responsive Navigation**: Mobile-friendly hamburger menu and adaptive layouts

## External Dependencies

### CDN Resources
- **Font Awesome 6.0.0**: Icon library for UI elements and visual indicators
- **Chart.js 3.9.1**: Data visualization library for dashboard analytics and reporting charts

### Browser APIs
- **localStorage/sessionStorage**: Client-side data persistence and session management
- **DOM Manipulation**: Native browser APIs for dynamic content updates and user interactions

### No Backend Dependencies
- **No Server Requirements**: Entirely client-side application with no backend API calls
- **No Database**: All data managed through browser storage mechanisms
- **No Third-party Authentication**: Custom authentication system using local storage